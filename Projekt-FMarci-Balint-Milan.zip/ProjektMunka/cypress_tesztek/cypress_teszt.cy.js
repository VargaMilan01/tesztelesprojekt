describe('Matematika oldal tesztelése', () => {
  it('Oldal betöltése', () => {
    cy.visit('http://127.0.0.1:5500/index.html')
  })

  it('Oldal nyelve', () => {
    cy.get('html').should('have.attr', 'lang').and('match', /HU/i)
  })

  it('Karakterkódolás', () => {
      cy.get('meta').should('have.attr', 'charset').and('match', /UTF-8/i)
  })
  
  it('Címsor teszt', () => {
      cy.title().should('eq', 'Számtani, mértani sorozatok')
  })

  it('Css hivatkozás', () => {
      cy.get('head>link').should('have.attr', 'href').and('eq', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css')
  })

  it('Legalább 3 carousel-itemet tartalmaz az oldal', () => {
    cy.get('.carousel-item').should('have.length.at.least', 3)
  })

  it('Navbar működése', () => {
    cy.get('.navbar-nav>li:nth-child(1)>a').click().should('have.attr', 'href').and('eq', '#szamtani')
    cy.get('.navbar-nav>li:nth-child(2)>a').click().should('have.attr', 'href').and('eq', '#mertani')
  })

  it('Mértani számítások működése', () => {
    cy.get('#mt_a1').type('10', { force: true })
    cy.get('#mt_q').type('2', { force: true })
    cy.get('#mt_n').type('5', { force: true })
    cy.get('#mt_szamol').click({ force: true })

    cy.get('#mt_an').should('have.text', '160', { force: true })
    cy.get('#mt_Sn').should('have.text', '310', { force: true })
  })

  it('Félkövér szöveg ellenőrzése', () => {
    cy.get('.accordion-body').first().should('contain', 'A számtani sorozat').find('strong')
  })

  it('Betűméret ellenőrzése', () => {
    cy.get('.accordion-body').should('have.css', 'font-size', '16px')
  })  
})